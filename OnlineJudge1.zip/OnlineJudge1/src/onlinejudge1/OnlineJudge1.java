/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package onlinejudge1;

/**
 *
 * @author DILIP JI
 */
public class OnlineJudge1 {

    /**
     * @param args the command line arguments
     * 
     */
    
  /*  public OnlineJudge1()
    {
    // initComponents();  
        initComponents();
    }*/
    
    public static void main(String[] args) {
        // TODO code application logic here
       
        new Mainserver().setVisible(true);
      
    }
}
