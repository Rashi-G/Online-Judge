/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package onlineclient;

/**
 *
 * @author DILIP JI
 */
public class OnlineClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new connect().setVisible(true);
       // Mainserver obj=new Mainserver();
    }
}
